package com.company;

public class GraphInit {


}